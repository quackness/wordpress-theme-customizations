<div class="cww-theme-steps-list">
	<div class="left-box-wrapper-outer cww-changelogs">
		<h3 class="cww-box-header"><?php esc_html_e('Changelogs','cww-portfolio'); ?></h3>
		
		<h4>
		<a href="https://themes.trac.wordpress.org/browser/<?php echo esc_attr(get_stylesheet())?>/<?php echo esc_attr(CWW_PORTFOLIO_VER)?>/readme.txt#L145"><?php esc_html_e('View Change Logs','cww-portfolio');?></a>
		</h4>
</div>
<?php $this->admin_sidebar_contents(); ?>
</div>